package com.myicons.ios;
import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;
public class MainActivity extends Activity {
    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        TextView t = new TextView(this);
        t.setText("iOS Icons installed.\nLauncher settings -> Icon pack -> iOS Icons");
        t.setTextSize(18); t.setPadding(48, 120, 48, 48);
        setContentView(t);
    }
}
